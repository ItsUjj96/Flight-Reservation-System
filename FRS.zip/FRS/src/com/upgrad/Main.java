package com.upgrad;

public class Main {

    public static void main(String[] args) {

        /*
       Flight f=new Flight();
       f.setAirline("indigo");
       f.setFlightNumber("H1287");
       f.setBookedSeats(123);  */


       /* Passenger.Address a= new Passenger.Address();
        Passenger.Contact c= new Passenger.Contact();
        */


        Passenger p = new Passenger(null, null, 25);
        Flight f= new Flight();



       Ticket t= new TouristTicket("H1n1", "Nagpur", "Delhi", "12.30", "3.30", p, "25", 2500, true, f, "kolkata",
               "Shimla");
        printTicketDetails(t);

        Ticket r= new RegularTicket("BNR123", "Nagaland", "Jammu", "5.30", "6.30", p, "36", 2500, false, f, "No");
       //Ticket r= new RegularTicket();



       /*
       System.out.println(f.getFlightNumber());
       System.out.println(f.getAirline());
        System.out.println(f.getBookedSeats());  */



    }

    public static void printTicketDetails(Ticket t){

        System.out.println(t.getPnr());


    }

}
