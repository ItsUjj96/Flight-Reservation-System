package com.upgrad;

public class Passenger {


    private Address address;
    private Contact contact;
    private static int idCounter;



    public Passenger (Address address, Contact contact, int idCounter){
        this.address=address;
        this.contact=contact;
        this.idCounter=idCounter;
        idCounter++;

    }

    private static class Contact{
        private String name;
        private String phoneNumber;
        private String emailId;
    }

    private static class Address{
        private String street;
        private String city;
        private String state;

    }


    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public int getPassengerCount(){
        return idCounter;

    }

}
