package com.upgrad;

public class RegularTicket extends Ticket {

    private String specialServices;

    public RegularTicket(String pnr, String from, String to, String departureDateTime, String arriveDateTime, Passenger passenger, String seatNo, float price, boolean cancelled, Flight flight, String specialServices) {
        super(pnr, from, to, departureDateTime, arriveDateTime, passenger, seatNo, price, cancelled, flight);
        this.specialServices = specialServices;
    }

    public String getSpecialServices() {
        return specialServices;
    }

    public void setSpecialServices(String specialServices) {
        this.specialServices = specialServices;
    }
}
